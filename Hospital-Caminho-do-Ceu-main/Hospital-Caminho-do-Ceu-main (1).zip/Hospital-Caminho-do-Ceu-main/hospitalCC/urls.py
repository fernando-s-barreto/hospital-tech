from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('cadastrar-paciente/', cadastrar_paciente, name='cadastrar_paciente'),
    path('cadastrar-triagem/', cadastrar_triagem, name='cadastrar_triagem'),
    path('cadastrar-funcionario/', cadastrar_funcionario, name='cadastrar_funcionario'),
    path('cadastrar-cargo/', cadastrar_cargo, name='cadastrar_cargo'),
    path('cadastrar-setor/', cadastrar_setor, name='cadastrar_setor'),
    path('cadastrar-recepcao/', cadastrar_recepcao, name='cadastrar_recepcao'),
    path('cadastrar-consulta/', cadastrar_consulta, name='cadastrar_consulta'),
    path('cadastrar-marcacao/', cadastrar_marcacao, name='cadastrar_marcacao'),
    path('cadastrar-laboratorio/', cadastrar_laboratorio, name='cadastrar_laboratorio'),
    path('cadastrar-exame/', cadastrar_exame, name='cadastrar_exame'),
    path('cadastrar-exame-paciente/', cadastrar_exame_paciente, name='cadastrar_exame_paciente'),
]